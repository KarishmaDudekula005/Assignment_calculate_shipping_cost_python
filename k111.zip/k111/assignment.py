def calculate_shipping_cost(packages, distance):
    """
    Calculate total shipping cost for a list of packages based on weight, shipping option, and distance.

    Args:
        packages (list of dict): List of packages, each with 'weight' and 'shipping_option'.
        distance (float): Distance in kilometers.

    Returns:
        float: Total shipping cost after applying any applicable discounts.

    Raises:
        ValueError: If weight is invalid (e.g., negative).
    """
    
    # Define base rates and multipliers
    base_rate = 5.00  # base rate per package
    weight_rate = 1.50  # rate per kg
    distance_rate = 0.05  # rate per km
    
    total_cost = 0.0

    # Iterate over packages to calculate the cost for each
    for package in packages:
        weight = package.get('weight', 0)
        shipping_option = package.get('shipping_option', 'standard')
        
        # Error handling for invalid weights
        if weight < 0:
            raise ValueError(f"Invalid weight: {weight}. Weight must be non-negative.")
        
        # Calculate cost based on shipping option
        if shipping_option == 'express':
            cost = base_rate + (weight * weight_rate * 1.2) + (distance * distance_rate * 1.5)
        else:
            cost = base_rate + (weight * weight_rate) + (distance * distance_rate)
        
        total_cost += cost

    # Apply a 10% discount if there are more than 3 packages
    if len(packages) > 3:
        total_cost *= 0.9  # apply 10% discount
    
    return round(total_cost, 2)


# Test cases to validate the functionality of the calculate_shipping_cost function
def test_calculate_shipping_cost():
    test_cases = [
        # Test case 1: No packages
        ([], 100, 0.0),
        
        # Test case 2: Standard and express options with valid weights
        ([{'weight': 2, 'shipping_option': 'standard'},
          {'weight': 5, 'shipping_option': 'express'},
          {'weight': 1, 'shipping_option': 'standard'}], 100, 46.0),
        
        # Test case 3: More than 3 packages (applies discount)
        ([{'weight': 2, 'shipping_option': 'standard'},
          {'weight': 5, 'shipping_option': 'express'},
          {'weight': 1, 'shipping_option': 'standard'},
          {'weight': 3, 'shipping_option': 'standard'}], 100, 54.45),  # Corrected expected value
        
        # Test case 4: Invalid weight (negative value) should raise an error
        ([{'weight': -2, 'shipping_option': 'standard'}], 100, "ValueError")
    ]

    for i, (packages, distance, expected) in enumerate(test_cases):
        try:
            result = calculate_shipping_cost(packages, distance)
            assert result == expected, f"Test case {i + 1} failed: Expected {expected}, got {result}"
            print(f"Test case {i + 1} passed.")
        except ValueError as e:
            assert str(e) == "Invalid weight: -2. Weight must be non-negative.", f"Test case {i + 1} failed: {e}"
            print(f"Test case {i + 1} passed (raised expected ValueError).")

# Run tests
test_calculate_shipping_cost()
